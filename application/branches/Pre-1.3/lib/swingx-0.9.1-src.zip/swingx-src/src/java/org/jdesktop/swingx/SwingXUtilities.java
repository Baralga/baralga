/**
 * 
 */
package org.jdesktop.swingx;

import java.awt.Component;


/**
 * @author Karl George Schaefer
 *
 */
public final class SwingXUtilities {
    private SwingXUtilities() {
        //does nothing
    }
    
    public void updateComponentTreeLocale(Component c) {
        
    }
}
