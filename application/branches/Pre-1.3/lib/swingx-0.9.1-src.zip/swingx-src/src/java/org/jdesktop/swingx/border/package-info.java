/**
 * Contains extensions to the {@code javax.swingx.border} package.
 */
package org.jdesktop.swingx.border;

