/**
 * 
 */
package org.jdesktop.swingx.autocomplete;

import java.awt.event.KeyAdapter;

/**
 * @author Karl George Schaefer
 *
 */
class AutoCompleteKeyAdapter extends KeyAdapter {

}
